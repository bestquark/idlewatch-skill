export const OPENCLAW_FLEET_SCHEMA = Object.freeze({
  family: 'idlewatch.openclaw.fleet',
  version: '1.2.0',
  backwardCompatibleWith: ['0.x-flat-row']
})

export function enrichWithOpenClawFleetTelemetry(sample, context = {}) {
  const host = context.host ?? sample.host ?? null
  const collector = context.collector ?? 'idlewatch-agent'
  const collectorVersion = context.collectorVersion ?? null
  const collectedAtMs = context.collectedAtMs ?? sample.ts ?? null

  return {
    ...sample,
    schemaFamily: OPENCLAW_FLEET_SCHEMA.family,
    schemaVersion: OPENCLAW_FLEET_SCHEMA.version,
    schemaCompat: OPENCLAW_FLEET_SCHEMA.backwardCompatibleWith,
    fleet: {
      host,
      collectedAtMs,
      resources: {
        cpuPct: sample.cpuPct ?? null,
        memUsedPct: sample.memUsedPct ?? sample.memPct ?? null,
        memPressurePct: sample.memPressurePct ?? null,
        memPressureClass: sample.memPressureClass ?? 'unavailable',
        tempC: sample.deviceTempC ?? null,
        thermalLevel: sample.thermalLevel ?? null,
        thermalState: sample.thermalState ?? 'unavailable'
      },
      usage: {
        model: sample.openclawModel ?? null,
        provider: sample.openclawProvider ?? null,
        totalTokens: sample.openclawTotalTokens ?? null,
        inputTokens: sample.openclawInputTokens ?? null,
        outputTokens: sample.openclawOutputTokens ?? null,
        remainingTokens: sample.openclawRemainingTokens ?? null,
        percentUsed: sample.openclawPercentUsed ?? null,
        contextTokens: sample.openclawContextTokens ?? null,
        budgetKind: sample.openclawBudgetKind ?? null,
        tokensPerMin: sample.tokensPerMin ?? null,
        sessionId: sample.openclawSessionId ?? null,
        agentId: sample.openclawAgentId ?? null,
        usageTimestampMs: sample.openclawUsageTs ?? null,
        usageAgeMs: sample.openclawUsageAgeMs ?? null,
        freshnessState: sample.source?.usageFreshnessState ?? null,
        integrationStatus: sample.source?.usageIntegrationStatus ?? 'unavailable',
        ingestionStatus: sample.source?.usageIngestionStatus ?? 'unavailable',
        activityStatus: sample.source?.usageActivityStatus ?? 'unavailable',
        alertLevel: sample.source?.usageAlertLevel ?? 'critical',
        alertReason: sample.source?.usageAlertReason ?? 'ingestion-unavailable'
      },
      providerQuotas: Array.isArray(sample.providerQuotas) ? sample.providerQuotas : [],
      providerConnections: Array.isArray(sample.providerConnections) ? sample.providerConnections : [],
      provenance: {
        collector,
        collectorVersion,
        usageSource: sample.source?.usage ?? 'unavailable',
        usageCommand: sample.source?.usageCommand ?? null,
        usageProbeResult: sample.source?.usageProbeResult ?? 'unavailable',
        usageProbeAttempts: sample.source?.usageProbeAttempts ?? 0,
        usageUsedFallbackCache: sample.source?.usageUsedFallbackCache ?? false,
        usageFallbackCacheSource: sample.source?.usageFallbackCacheSource ?? null
      }
    }
  }
}
